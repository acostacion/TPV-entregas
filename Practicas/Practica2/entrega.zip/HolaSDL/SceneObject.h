#pragma once	
#include "GameObject.h"
#include "gameList.h"
#include "Vector2D.h"
#include "Collision.h"
#include "Texture.h"
#include <SDL_rect.h>

class Game;

class SceneObject : public GameObject{ // SceneObject hereda de GameObject.
protected:
	// Propiedades.
	Point2D<float>pos;
	float width = texture->getFrameWidth();
	float height = texture->getFrameHeight();

	// Referencias.
	Texture* texture = nullptr;
	Game* game = nullptr;

	// HAY QUE METER LO DEL ANCHOR.

	SDL_Rect getCollisionRect();
	SDL_Rect getRenderRect() const;

	// Iterador de sceneobjects.
	GameList<SceneObject>::anchor anchor;

public:
	// Constructores y Destructores.
	SceneObject(Game* _game, Point2D<float> _pos, float _W, float _h, Texture* _textue);

	// M�todos.
	virtual Collision hit(const SDL_Rect& rect, Collision::Target target) = 0; // Detecta colisi�n con otro rect�ngulo
	Collision tryToMove(const Vector2D<float>& speed, Collision::Target target);

	void setListAnchor(GameList<SceneObject>::anchor&& anchor) {
		this->anchor = std::move(anchor);
	}

	// Getters.
	Point2D<float> getPosition() const { return pos; }
	float getWidth() const { return width; } 
	float getHeight() const { return height; } 
	Texture* getTexture() const { return texture; } 
	
};

